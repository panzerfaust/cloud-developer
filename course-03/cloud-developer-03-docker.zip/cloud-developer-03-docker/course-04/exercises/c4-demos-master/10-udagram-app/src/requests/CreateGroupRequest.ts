export interface CreateGroupRequest {
  name: string
  description: string
}
