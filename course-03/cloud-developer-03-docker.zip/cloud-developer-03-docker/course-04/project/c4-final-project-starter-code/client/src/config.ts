const apiId = '...'
export const apiEndpoint = `https://${apiId}.execute-api.us-east-1.amazonaws.com/dev`

export const authConfig = {
  domain: '...',
  clientId: '...',
  callbackUrl: 'http://localhost:3000/callback'
}
