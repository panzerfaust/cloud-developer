import { User } from './users/models/User';

export const V0MODELS = [ User ];
