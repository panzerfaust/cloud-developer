export interface Group {
  id: string
  name: string
  description: string
  userId: string
  timestamp: string
}
